# myeden_static
