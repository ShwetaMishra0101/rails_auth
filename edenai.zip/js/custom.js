function _0x1e40(_0x10a6f5, _0x16d94b) {
  var _0x3e7441 = _0x3e74();
  return (
    (_0x1e40 = function (_0x1e4093, _0x26a9f6) {
      _0x1e4093 = _0x1e4093 - 0x1bf;
      var _0x292828 = _0x3e7441[_0x1e4093];
      return _0x292828;
    }),
    _0x1e40(_0x10a6f5, _0x16d94b)
  );
}
(function (_0x58340d, _0x181840) {
  var _0x267955 = _0x1e40,
    _0x11939a = _0x58340d();
  while (!![]) {
    try {
      var _0x324a39 =
        -parseInt(_0x267955(0x1d0)) / 0x1 +
        -parseInt(_0x267955(0x1d5)) / 0x2 +
        (-parseInt(_0x267955(0x20b)) / 0x3) * (parseInt(_0x267955(0x215)) / 0x4) +
        (parseInt(_0x267955(0x1d9)) / 0x5) * (parseInt(_0x267955(0x1e9)) / 0x6) +
        -parseInt(_0x267955(0x1f6)) / 0x7 +
        -parseInt(_0x267955(0x216)) / 0x8 +
        (parseInt(_0x267955(0x1d8)) / 0x9) * (parseInt(_0x267955(0x21f)) / 0xa);
      if (_0x324a39 === _0x181840) break;
      else _0x11939a["push"](_0x11939a["shift"]());
    } catch (_0x238c31) {
      _0x11939a["push"](_0x11939a["shift"]());
    }
  }
})(_0x3e74, 0xcfa4b),
  (function (_0x3d8837) {
    "use strict";
    var _0x1f28a8 = _0x1e40;
    function _0x574531() {
      var _0x461b2b = _0x1e40;
      _0x3d8837("iframe")[_0x461b2b(0x222)](function () {
        var _0x4ed820 = _0x461b2b;
        _0x3d8837(this)[0x0][_0x4ed820(0x21c)][_0x4ed820(0x1ee)](_0x4ed820(0x1eb), "*");
      });
    }
    _0x3d8837(window)["on"](_0x1f28a8(0x1bf), function () {
      var _0x49ebb3 = _0x1f28a8,
        _0x4c83ac = _0x3d8837(_0x49ebb3(0x207));
      setTimeout(function () {
        var _0x5b3fa5 = _0x49ebb3;
        _0x4c83ac[_0x5b3fa5(0x1ce)](_0x5b3fa5(0x1c3));
      }, 0x320);
      _0x3d8837(window)[_0x49ebb3(0x20c)]() > 0x400
        ? (setTimeout(function () {
            var _0x247045 = _0x49ebb3;
            _0x3d8837(_0x247045(0x1cf))[_0x247045(0x1ce)](_0x247045(0x1c1));
          }, 0x5dc),
          setTimeout(function () {
            var _0x29b10d = _0x49ebb3;
            _0x3d8837(_0x29b10d(0x1d2))[_0x29b10d(0x1ce)](_0x29b10d(0x1f4)), _0x3d8837(_0x29b10d(0x1ca))[_0x29b10d(0x1ce)](_0x29b10d(0x1f4)), _0x3d8837(_0x29b10d(0x1c2))[_0x29b10d(0x1ce)](_0x29b10d(0x1f4));
          }, 0x898))
        : (setTimeout(function () {
            var _0x70e49f = _0x49ebb3;
            _0x3d8837(_0x70e49f(0x1cf))[_0x70e49f(0x1ce)](_0x70e49f(0x1c1));
          }, 0x44c),
          setTimeout(function () {
            var _0x4077fd = _0x49ebb3;
            _0x3d8837(".home>div>div\x20h1\x20span\x20span")["addClass"]("animated\x20fadeInUp"), _0x3d8837(_0x4077fd(0x1ca))[_0x4077fd(0x1ce)](_0x4077fd(0x1f4)), _0x3d8837(_0x4077fd(0x1c2))[_0x4077fd(0x1ce)]("animated\x20fadeInUp");
          }, 0x708));
      var _0x2d52e1 = _0x3d8837(_0x49ebb3(0x225))[_0x49ebb3(0x20c)]() - 0xa,
        _0x4dbbb3 = _0x2d52e1 + _0x3d8837(_0x49ebb3(0x220))[_0x49ebb3(0x20c)]() + _0x3d8837(_0x49ebb3(0x1e0))[_0x49ebb3(0x20c)]() - 0xa,
        _0x1d8a1d = _0x4dbbb3 + _0x3d8837(".portfolio\x20.single-item\x20.main-content")[_0x49ebb3(0x20c)]() + _0x3d8837(_0x49ebb3(0x214))["width"]() + 0xfa + 0x41 + 0x12c + _0x3d8837(".clients")[_0x49ebb3(0x20c)]() - 0xa,
        _0x207de5 = _0x1d8a1d + _0x3d8837(_0x49ebb3(0x1f1))["width"]() + _0x3d8837(_0x49ebb3(0x226))["width"]() - 0xa,
        _0x48d464 = _0x207de5 + _0x3d8837(_0x49ebb3(0x1cb))[_0x49ebb3(0x20c)]() + _0x3d8837(_0x49ebb3(0x203))["width"]() - 0xa;
      function _0x400648() {
        var _0x3d5b70 = _0x49ebb3,
          _0x170178 = _0x3d8837(_0x3d5b70(0x1df))[_0x3d5b70(0x20c)]() - _0x3d8837(window)["width"]() / 0x2 + 0x10e,
          _0x876013 = _0x3d8837(_0x3d5b70(0x201));
        _0x876013["each"](function () {
          var _0x51c6ea = _0x3d5b70,
            _0x4dcb28 = _0x3d8837(this),
            _0x294e52 = _0x3d8837(this)[_0x51c6ea(0x1ec)]()[_0x51c6ea(0x20e)];
          if (_0x294e52 < _0x170178) {
            if (_0x4dcb28[_0x51c6ea(0x20a)](_0x51c6ea(0x1e5))) _0x4dcb28["addClass"](_0x51c6ea(0x1d3));
            else {
              if (_0x4dcb28[_0x51c6ea(0x20a)](_0x51c6ea(0x1cc))) _0x4dcb28["addClass"](_0x51c6ea(0x1f4));
              else {
                if (_0x4dcb28[_0x51c6ea(0x20a)](_0x51c6ea(0x208))) _0x4dcb28[_0x51c6ea(0x1ce)]("animated\x20fadeIn");
                else {
                  if (_0x4dcb28[_0x51c6ea(0x20a)](_0x51c6ea(0x20d))) _0x4dcb28[_0x51c6ea(0x1ce)](_0x51c6ea(0x1c1));
                  else {
                    if (_0x4dcb28["hasClass"](_0x51c6ea(0x204))) _0x4dcb28[_0x51c6ea(0x1ce)](_0x51c6ea(0x1dd));
                    else _0x4dcb28[_0x51c6ea(0x20a)](_0x51c6ea(0x224)) && _0x4dcb28[_0x51c6ea(0x1ce)](_0x51c6ea(0x1ed));
                  }
                }
              }
            }
          }
        });
      }
      function _0x1e6393() {
        var _0x11720f = _0x49ebb3;
        if (Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(_0x11720f(0x223))[_0x11720f(0x218)](_0x11720f(0x20e)), 0xa)) > _0x2d52e1 && Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(_0x11720f(0x223))[_0x11720f(0x218)]("left"), 0xa)) < _0x4dbbb3)
          _0x3d8837(_0x11720f(0x210))["removeClass"]("active"), _0x3d8837(_0x11720f(0x200))[_0x11720f(0x1ce)](_0x11720f(0x1c4));
        else {
          if (
            Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(_0x11720f(0x223))[_0x11720f(0x218)](_0x11720f(0x20e)), 0xa)) > _0x4dbbb3 &&
            Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(".mCSB_container")[_0x11720f(0x218)](_0x11720f(0x20e)), 0xa)) < _0x1d8a1d
          )
            _0x3d8837(_0x11720f(0x210))[_0x11720f(0x1de)](_0x11720f(0x1c4)), _0x3d8837(_0x11720f(0x1d1))[_0x11720f(0x1ce)](_0x11720f(0x1c4));
          else {
            if (
              Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(".mCSB_container")[_0x11720f(0x218)](_0x11720f(0x20e)), 0xa)) > _0x1d8a1d &&
              Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(_0x11720f(0x223))[_0x11720f(0x218)](_0x11720f(0x20e)), 0xa)) < _0x207de5
            )
              _0x3d8837(".menu\x20ul\x20li\x20span")[_0x11720f(0x1de)](_0x11720f(0x1c4)), _0x3d8837(_0x11720f(0x1d4))[_0x11720f(0x1ce)](_0x11720f(0x1c4));
            else
              Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(_0x11720f(0x223))[_0x11720f(0x218)](_0x11720f(0x20e)), 0xa)) > _0x207de5 && Math[_0x11720f(0x1f3)](parseInt(_0x3d8837(_0x11720f(0x223))["css"](_0x11720f(0x20e)), 0xa)) < _0x48d464
                ? (_0x3d8837(_0x11720f(0x210))["removeClass"]("active"), _0x3d8837(_0x11720f(0x1f7))[_0x11720f(0x1ce)](_0x11720f(0x1c4)))
                : (_0x3d8837(".menu\x20ul\x20li\x20span")[_0x11720f(0x1de)](_0x11720f(0x1c4)), _0x3d8837(_0x11720f(0x1fb))["addClass"]("active"));
          }
        }
      }
      _0x3d8837(_0x49ebb3(0x1df))["length"] &&
        (_0x3d8837(window)[_0x49ebb3(0x20c)]() > 0x400
          ? _0x3d8837(_0x49ebb3(0x1df))[_0x49ebb3(0x213)]({
              axis: "x",
              theme: "dark-3",
              keyboard: { enable: !![], scrollType: "stepless" },
              advanced: { autoExpandHorizontalScroll: !![] },
              mouseWheel: { scrollAmount: 0x190 },
              callbacks: {
                whileScrolling: function () {
                  _0x400648(), _0x1e6393();
                },
              },
            })
          : ((WOW = new WOW({ boxClass: _0x49ebb3(0x21e), animateClass: _0x49ebb3(0x1d3), offset: 0x64, mobile: !![], live: !![] })), WOW[_0x49ebb3(0x1e3)]()));
    }),
      _0x3d8837(document)[_0x1f28a8(0x1c5)](function () {
        var _0x358261 = _0x1f28a8,
          _0x48a4ad = /^((?!chrome|android).)*safari/i[_0x358261(0x1c7)](navigator[_0x358261(0x1e7)]);
        _0x48a4ad && _0x3d8837(_0x358261(0x21d))["addClass"](_0x358261(0x1c6));
        _0x3d8837("a[href=\x27#\x27]")["on"](_0x358261(0x205), function (_0x3fd567) {
          _0x3fd567["preventDefault"]();
        });
        function _0x1c6629() {
          var _0x26dc0d = _0x358261;
          history[_0x26dc0d(0x1f9)]("", document[_0x26dc0d(0x1d6)], window[_0x26dc0d(0x209)][_0x26dc0d(0x1e8)] + window[_0x26dc0d(0x209)][_0x26dc0d(0x1da)] + window[_0x26dc0d(0x209)][_0x26dc0d(0x1c8)]);
        }
        _0x3d8837(_0x358261(0x1e2))["on"](_0x358261(0x205), function (_0x3ea456) {
          setTimeout(() => {
            _0x1c6629();
          }, 0x5);
        });
        _0x3d8837(window)[_0x358261(0x20c)]() > 0x400 &&
          (_0x3d8837(_0x358261(0x21a))[_0x358261(0x1de)](_0x358261(0x212)),
          _0x3d8837(_0x358261(0x1e6))[_0x358261(0x1de)]("fadeInUp"),
          _0x3d8837(_0x358261(0x217))[_0x358261(0x1de)](_0x358261(0x1fa)),
          _0x3d8837(_0x358261(0x1cd))[_0x358261(0x1de)](_0x358261(0x1db)),
          _0x3d8837(_0x358261(0x1f8))[_0x358261(0x1de)](_0x358261(0x211)));
        _0x3d8837(_0x358261(0x210))["on"](_0x358261(0x205), function () {
          setTimeout(function () {
            var _0xc80dd3 = _0x1e40;
            _0x3d8837(this)[_0xc80dd3(0x20f)](_0xc80dd3(0x1c4));
          }, 0x640);
        }),
          _0x3d8837("#home-link")["on"](_0x358261(0x205), function () {
            var _0x118158 = _0x358261;
            _0x3d8837(_0x118158(0x1df))[_0x118158(0x213)](_0x118158(0x1ef), _0x118158(0x1fd), { scrollInertia: 0x5dc });
          }),
          _0x3d8837(_0x358261(0x200))["on"](_0x358261(0x205), function () {
            var _0x54b1b9 = _0x358261;
            _0x3d8837(_0x54b1b9(0x1df))[_0x54b1b9(0x213)]("scrollTo", _0x54b1b9(0x202), { scrollInertia: 0x5dc });
          }),
          _0x3d8837(_0x358261(0x1d1))["on"](_0x358261(0x205), function () {
            var _0x245afc = _0x358261;
            _0x3d8837(_0x245afc(0x1df))["mCustomScrollbar"](_0x245afc(0x1ef), _0x245afc(0x227), { scrollInertia: 0x5dc });
          }),
          _0x3d8837("#contact-link")["on"](_0x358261(0x205), function () {
            var _0x7504c = _0x358261;
            _0x3d8837(_0x7504c(0x1df))["mCustomScrollbar"]("scrollTo", _0x7504c(0x1e4), { scrollInertia: 0x5dc });
          }),
          _0x3d8837(_0x358261(0x1f7))["on"]("click", function () {
            var _0x1c75cd = _0x358261;
            _0x3d8837(_0x1c75cd(0x1df))[_0x1c75cd(0x213)](_0x1c75cd(0x1ef), _0x1c75cd(0x1e1), { scrollInertia: 0x5dc });
          }),
          _0x3d8837(_0x358261(0x1e2))["on"](_0x358261(0x205), function () {
            var _0x41cec0 = _0x358261;
            _0x3d8837(_0x41cec0(0x1fe))[_0x41cec0(0x1c9)]("click");
          }),
          _0x3d8837(_0x358261(0x1ea))["on"]("click", function () {
            var _0x1a3e37 = _0x358261;
            _0x3d8837(window)[_0x1a3e37(0x20c)]() > 0x400
              ? _0x3d8837(_0x1a3e37(0x1df))[_0x1a3e37(0x213)](_0x1a3e37(0x1ef), _0x1a3e37(0x202), { scrollInertia: 0x5dc })
              : _0x3d8837(_0x1a3e37(0x1fc))["animate"]({ scrollTop: _0x3d8837(_0x1a3e37(0x1dc))[_0x1a3e37(0x1ec)]()[_0x1a3e37(0x1f5)] });
          });
        const _0x1b312c = new Swiper(_0x358261(0x1f2), {
          slidesPerView: 0x2,
          loop: !![],
          breakpoints: { 0x140: { slidesPerView: 0x1 }, 0x300: { slidesPerView: 0x2 }, 0x401: { slidesPerView: 0x3 } },
          spaceBetween: 0x32,
          grabCursor: !![],
          pagination: { el: _0x358261(0x1c0), clickable: !![], type: _0x358261(0x1ff) },
        });
        var _0x563bad = new Swiper(".swiper-portfolio", {
            loop: !![],
            navigation: { nextEl: _0x358261(0x206), prevEl: _0x358261(0x219) },
            breakpoints: { 0x140: { slidesPerView: 1.2, spaceBetween: 0x1e, navigation: ![] }, 0x300: { slidesPerView: _0x358261(0x221), spaceBetween: 0x0 }, 0x401: { direction: _0x358261(0x21b) } },
          }),
          _0x472f72 = new Swiper(_0x358261(0x1f0), { slidesPerView: 0x1, loop: !![], pagination: { el: ".swiper-pagination", clickable: !![], type: _0x358261(0x1ff) } });
        _0x563bad["on"](_0x358261(0x1d7), function () {
          _0x574531();
        });
      });

      $(document).on("click", "#indexcta", function(){
        $('html, body').animate({
          scrollTop: $(".clients").offset().top
        }, 500);
      })

      $(document).on("click", "#go-to-contact", function(){
        $('html, body').animate({
          scrollLeft: $("#contact").offset().left
        }, 500);
      })

  })(jQuery);
function _0x3e74() {
  var _0x2a7019 = [
    "wow",
    "42960460GkhHAJ",
    ".about",
    "auto",
    "each",
    ".mCSB_container",
    "fade-in-left-animation",
    ".home",
    ".testimonials",
    "#portfolio",
    "load",
    ".swiper-pagination",
    "animated\x20fadeInDown",
    ".home\x20.cta",
    "preloaded",
    "active",
    "ready",
    "body-safari",
    "test",
    "search",
    "trigger",
    ".home>div>div\x20.intro",
    ".blog",
    "fade-in-up-animation",
    ".fadeInRight",
    "addClass",
    ".header-inner",
    "586264YVDJBL",
    "#portfolio-link",
    ".home>div>div\x20h1\x20span\x20span",
    "animated",
    "#contact-link",
    "1948700WCcfgD",
    "title",
    "slideChange",
    "9VelOWj",
    "5tzAyFG",
    "pathname",
    "fadeInRight",
    "#my-photo",
    "animated\x20fadeInRight",
    "removeClass",
    "#wrapper",
    ".facts",
    "#blog",
    "#menu\x20li\x20a",
    "init",
    "#contact",
    "image-animation",
    ".fadeInUp",
    "userAgent",
    "origin",
    "4359114ciHrsA",
    "#cta",
    "{\x22event\x22:\x22command\x22,\x22func\x22:\x22pauseVideo\x22,\x22args\x22:\x22\x22}",
    "offset",
    "animated\x20fadeInLeft",
    "postMessage",
    "scrollTo",
    ".swiper-portfolio-item",
    ".contact",
    ".swiper-clients",
    "abs",
    "animated\x20fadeInUp",
    "top",
    "5206243mXLDww",
    "#blog-link",
    ".fadeInLeft",
    "replaceState",
    "fadeInDown",
    "#home-link",
    "html,\x20body",
    "#home",
    "#checkboxmenu",
    "bullets",
    "#about-link",
    ".animated-layer",
    "#about",
    ".copyright",
    "fade-in-right-animation",
    "click",
    ".next-item",
    "#preloader",
    "fade-in-animation",
    "location",
    "hasClass",
    "555612vSnNGR",
    "width",
    "fade-in-down-animation",
    "left",
    "toggleClass",
    ".menu\x20ul\x20li\x20span",
    "fadeInLeft",
    "fadeIn",
    "mCustomScrollbar",
    ".portfolio\x20.single-item\x20.details",
    "4hCAzDy",
    "13459928HmwQBD",
    ".fadeInDown",
    "css",
    ".prev-item",
    ".fadeIn",
    "vertical",
    "contentWindow",
    "body",
  ];
  _0x3e74 = function () {
    return _0x2a7019;
  };
  return _0x3e74();
}
